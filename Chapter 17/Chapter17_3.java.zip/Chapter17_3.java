import java.io.*;
import java.io.IOException;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

// Ask team why the file is not being found

public class Chapter17_3 {
	public static void main(String[] args) throws IOException {
		
		// Make a .dat file
		
		setOutput();
		inPut();
		
		// Create a new file with DataOutputStream and FileOutputStream, include for loops
	}
			
		
		public static void setOutput() {
			try (DataOutputStream output = new DataOutputStream(new FileOutputStream("Exercise17_03.dat"));) {
				for (int i = 0; i < 100; i++) {
					output.writeInt((int)(Math.random() * 100));
				}
			}
			catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		
		public static void inPut() {
			int total = 0;
			try(DataInputStream input = new DataInputStream(new FileInputStream("Exercise17_03.dat"));) {
				
				while(true) {
					total += input.readInt();
				}
			}
			catch (EOFException ex) {
				System.out.println("Sum of numbers =" + total);	
			}
			catch (IOException ex) {
				ex.printStackTrace();
				
			}
		}	
		
}