/*
Adam Anderson
3/29/2019
he Loan classPreview the document in Listing 10.2 does not implement Serializable. Rewrite the Loan class to implement Serializable. Exercise17_07.java creates a file named Exercise17_07.dat containing Loan objects that were written using the ObjectOutputStream. Modify Exercise17_07 by adding a void function called outputData that reads the Loan objects from the file and displays the total loan amount. Suppose you don’t know how many Loan objects are there in the file, use EOFException to end the loop.
 
 **/
import java.io.*;
import java.io.EOFException;

public class Exercise17_07 {
    public static void main(String[] args) throws FileNotFoundException {
        Loan loan1 = new Loan();
        Loan loan2 = new Loan(1.8, 10, 10000);
        
        try (
                ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream("Exercise17_07.dat"));
        ) {
            output.writeObject(loan1);
            output.writeObject(loan2);
        } 
        catch (IOException ex) {
            System.out.println("File could not be opened");
        }
        outPutData();
    }
    
    // Following the format on page 696, but I'm not using arrays like the example
    public static void outPutData() {
        try (
            ObjectInputStream input = new ObjectInputStream(new FileInputStream("Exercise17_07.dat")); 
        ) {
            while(true) {
                
                Loan l1 = (Loan)(input.readObject());
                System.out.println("Loan Amount = " + l1.getLoanAmount());
            }
        }
        catch(EOFException e) {
            
        }   
        catch(IOException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}
