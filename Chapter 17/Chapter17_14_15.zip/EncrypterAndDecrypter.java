/*
Adam Anderson
4/1/2019
(Encrypt files) Encode the file by adding 5 to every byte in the file. Write a program that prompts the user to enter an input file name and an output file name and saves the encrypted version of the input file to the output file.


(Decrypt files) Suppose a file is encrypted using the scheme in Programming Exercise 17.14. Write a program to decode an encrypted file. Your program should prompt the user to enter an input file name for the encrypted file and an output file name for the unencrypted version of the input file.
**/

import java.io.*;
import java.util.Scanner;
import java.io.IOException;

public class EncrypterAndDecrypter {	
	
	private static File inputName;
	private static File outputName;
	private static File decryptionInputName;
	private static File decryptionOutputName;
		
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("If you'd like to encrypt a file press 1, if you'd like to decrypt a file press 2: ");
		int option = 0;
		option = scanner.nextInt();
		if (option == 1) {
			FileEncryption();
		}
		else
		FileDecryption();
	}	

	private static void FileEncryption() {	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Name the encryption file: ");
		inputName = new File(scanner.nextLine());
		System.out.println("Name the output file name: ");
		outputName = new File(scanner.nextLine());
		try (
			BufferedInputStream streamInput = new BufferedInputStream(new FileInputStream(inputName));
			BufferedOutputStream streamOutput = new BufferedOutputStream(new FileOutputStream(outputName))
		) {
			int total;
			while((total = streamInput.read()) != -1) streamOutput.write(total + 5);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static void FileDecryption() {	
		Scanner scanner = new Scanner(System.in);
		System.out.println("Name the file to decrypt: ");
		decryptionInputName = new File(scanner.nextLine());
		System.out.println("Name the new decrypted file name: ");
		decryptionOutputName = new File(scanner.nextLine());
		try (
			BufferedInputStream streamInput = new BufferedInputStream(new FileInputStream(decryptionInputName));
			BufferedOutputStream streamOutput = new BufferedOutputStream(new FileOutputStream(decryptionOutputName));
		) {
			int total;
			while((total = streamInput.read()) != -1) streamOutput.write(total - 5);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}