/*
Author: Adam Anderson
Date: 4/12/2019

Description: (Use Comparator ) Write the following generic method using selection sort and a comparator.

public static <E> void selectionSort(E[] list, Comparator<? super E> comparator)
Exercise20_21.javaPreview the document is a test program that creates an array of 10 and invokes this method using the GeometricObjectComparator introduced in Listing 20.4 to sort the elements. Display the sorted elements. Use the following statement to create the array.*/
import java.util.Comparator;
import java.util.Collection;
import java.util.Collections;

public class Exercise20_21 {
	public static void main(String[] args) {
		GeometricObject[] list = {new Circle(5), new Rectangle(4, 5),
				new Circle(5.5), new Rectangle(2.4, 5), new Circle(0.5), 
				new Rectangle(4, 65), new Circle(4.5), new Rectangle(4.4, 1),
				new Circle(6.5), new Rectangle(4, 5)};

		Circle[] list1 = {new Circle(2), new Circle(3), new Circle(2),
			new Circle(5), new Circle(6), new Circle(1), new Circle(2),
			new Circle(3), new Circle(14), new Circle(12)};
	
		selectionSort(list, new GeometricObjectComparator());
	}
	public static <E> void selectionSort(E[] list, Comparator<? super E> comparator) {
		
		int n = list.length;
		
		for (int i = 0; i <= n- 1; i++) {
			int minIndex = i;
			for (int j = i + 1; j <= n-1; j++)
			if (comparator.compare(list[j], list[minIndex]) == -1) {
				minIndex = j;
			}
			
			E temp = list[minIndex];
			list[minIndex] = list[i];
			list[i] = temp;	
		}
		for (int i = 0; i < list.length; i++) {
			System.out.println(list[i] + " ");
		}
	}    
}