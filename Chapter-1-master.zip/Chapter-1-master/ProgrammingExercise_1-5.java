/*
Author: Adam Anderson
Date: 10/3/2018

This program performs an algebraic function using javascript.
*/

class Untitled {
	public static void main(String[] args) {
		System.out.println("(9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5) is ");
		System.out.println((9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5));
	}
}