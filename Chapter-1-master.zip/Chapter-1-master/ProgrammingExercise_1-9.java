/*
Author: Adam Anderson
Date: 10/3/2018

This program displays the area and perimeter of a rectangle.
*/

class Untitled {
	public static void main(String[] args) {
		System.out.print("Here is how we calculate the area and perimeter of a rectangle:");
		System.out.println("width =" + 4.5);
		System.out.println("height =" + 7.9);
		double width = 4.5;
		double height = 7.9;
		System.out.println("The area is equal to:");
		System.out.println(width * height); // (4.5 * 7.9)
		System.out.println("The perimeter is equal to the length of all sides, added together:");
		System.out.println(width + width + height + height); // (4.5 + 4.5 + 7.9 + 7.9)
	}
}